import * as lv from "lv"
import { app } from "lvapp"
import { img } from "/support_script/qjs/img.js"
import { pointer } from "/support_script/qjs/pointer.js"
class AOD_HS01WF005 extends app {
	constructor() {
		super(0);
	}
	start() {

		this.img0 = new img(this.root());
		this.img0.set_src(this.path() + "img0.bin");
		this.img0.set_pos(0,0);

		this.pointer1 = new pointer(this.root());
		this.pointer1.set_src(this.path() + "point1.bin");
		this.pointer1.set_range(0,3600);
		this.pointer1.set_pos(219,90);
		this.pointer1.set_pivot(14,143);
		this.pp_1 = lv.app_db_get_val_percent(150);
		this.pointer1.set_value(this.pp_1*(3600-0)/10000);
		this.pointer1.bind(150, function(idx, val) {
			this.pp_1 = lv.app_db_get_val_percent(150);
			this.set_value(this.pp_1*(3600-0)/10000);
		});

		this.pointer2 = new pointer(this.root());
		this.pointer2.set_src(this.path() + "point2.bin");
		this.pointer2.set_range(0,3600);
		this.pointer2.set_pos(219,13);
		this.pointer2.set_pivot(14,220);
		this.pp_2 = lv.app_db_get_val_percent(153);
		this.pointer2.set_value(this.pp_2*(3600-0)/10000);
		this.pointer2.bind(153, function(idx, val) {
			this.pp_2 = lv.app_db_get_val_percent(153);
			this.set_value(this.pp_2*(3600-0)/10000);
		});

		this.pointer3 = new pointer(this.root());
		this.pointer3.set_src(this.path() + "point3.bin");
		this.pointer3.set_range(0,3600);
		this.pointer3.set_pos(225,2);
		this.pointer3.set_pivot(8,231);
		this.pp_3 = lv.app_db_get_val_percent(154);
		this.pointer3.set_value(this.pp_3*(3600-0)/10000);
		this.pointer3.bind(154, function(idx, val) {
			this.pp_3 = lv.app_db_get_val_percent(154);
			this.set_value(this.pp_3*(3600-0)/10000);
		});

		this.img4 = new img(this.root());
		this.img4.set_src(this.path() + "img4.bin");
		this.img4.set_pos(214,214);
	}
	resume() {
		this.pp_1 = lv.app_db_get_val_percent(150);
		this.pointer1.set_value(this.pp_1*(3600-0)/10000);
		this.pp_2 = lv.app_db_get_val_percent(153);
		this.pointer2.set_value(this.pp_2*(3600-0)/10000);
		this.pp_3 = lv.app_db_get_val_percent(154);
		this.pointer3.set_value(this.pp_3*(3600-0)/10000);
	}
	pause() {
		this.task();
	}
}
globalThis.AOD_HS01WF005 = AOD_HS01WF005;
�1[�