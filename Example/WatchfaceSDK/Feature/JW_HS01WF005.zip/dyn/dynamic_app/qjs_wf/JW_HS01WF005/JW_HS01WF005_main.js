import * as lv from "lv"
import { app } from "lvapp"
import { img } from "/support_script/qjs/img.js"
import { gif } from "/support_script/qjs/gif.js"
import { pointer } from "/support_script/qjs/pointer.js"
class JW_HS01WF005 extends app {
	constructor() {
		super(1);
	}
	start() {

		this.img0 = new img(this.root());
		this.img0.set_src(this.path() + "img0.bin");
		this.img0.set_pos(0,0);

		if (lv.get_agif_support()) {
			this.gif1_src = this.path() + "gif1.agif";
		} else {
			this.gif1_src = this.path() + "gif1.gif";
		}
		this.gif1_ff_src = this.path() + "gif1_ff.bin";
		this.gif1 = new gif(this.root());
		this.gif1.anim_open(this.gif1_src, this.gif1_ff_src, 0, 0, 0, 98);

		this.pointer2 = new pointer(this.root());
		this.pointer2.set_src(this.path() + "point2.bin");
		this.pointer2.set_range(0,3600);
		this.pointer2.set_pos(219,90);
		this.pointer2.set_pivot(14,143);
		this.pp_2 = lv.app_db_get_val_percent(150);
		this.pointer2.set_value(this.pp_2*(3600-0)/10000);
		this.pointer2.bind(150, function(idx, val) {
			this.pp_2 = lv.app_db_get_val_percent(150);
			this.set_value(this.pp_2*(3600-0)/10000);
		});

		this.pointer3 = new pointer(this.root());
		this.pointer3.set_src(this.path() + "point3.bin");
		this.pointer3.set_range(0,3600);
		this.pointer3.set_pos(219,13);
		this.pointer3.set_pivot(14,220);
		this.pp_3 = lv.app_db_get_val_percent(153);
		this.pointer3.set_value(this.pp_3*(3600-0)/10000);
		this.pointer3.bind(153, function(idx, val) {
			this.pp_3 = lv.app_db_get_val_percent(153);
			this.set_value(this.pp_3*(3600-0)/10000);
		});

		this.pointer4 = new pointer(this.root());
		this.pointer4.set_src(this.path() + "point4.bin");
		this.pointer4.set_range(0,3600);
		this.pointer4.set_pos(225,2);
		this.pointer4.set_pivot(8,231);
		this.pp_4 = lv.app_db_get_val_percent(154);
		this.pointer4.set_value(this.pp_4*(3600-0)/10000);
		this.pointer4.bind(154, function(idx, val) {
			this.pp_4 = lv.app_db_get_val_percent(154);
			this.set_value(this.pp_4*(3600-0)/10000);
		});

		this.img5 = new img(this.root());
		this.img5.set_src(this.path() + "img5.bin");
		this.img5.set_pos(214,214);
	}
	resume() {
		this.gif1.anim_resume();
		this.pp_2 = lv.app_db_get_val_percent(150);
		this.pointer2.set_value(this.pp_2*(3600-0)/10000);
		this.pp_3 = lv.app_db_get_val_percent(153);
		this.pointer3.set_value(this.pp_3*(3600-0)/10000);
		this.pp_4 = lv.app_db_get_val_percent(154);
		this.pointer4.set_value(this.pp_4*(3600-0)/10000);
	}
	pause() {
		this.task();
		this.gif1.anim_pause();
	}
	stop() {
		this.gif1.anim_close();
	}
}
globalThis.JW_HS01WF005 = JW_HS01WF005;
  B4H�